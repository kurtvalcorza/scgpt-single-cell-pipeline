"""Review probes for scgpt_single_cell_colab, torch-free (stdlib + numpy-free).

P3  rebuild the default 64-cell dataset from the pinned vocabulary (sha256 ee2b2c90...) and the split; examine
    library sizes per class and recompute the majority and library-size baselines with the carried metrics, to
    test the notebook's "library-size baseline sits at chance by construction".
P4  BYOD loader (load_byod_dataset + validate_dataset) on constructed CSV / JSON / JSONL inputs; and the cell's
    upload branch outside Colab.
"""
import json, sys, statistics
from pathlib import Path

repo, vocab_path, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.path.insert(0, str(repo / "src"))
from scgpt_single_cell_pipeline import pipeline as P, samples as S, metrics as M

vocab = P.load_gene_vocabulary(vocab_path)
records = S.generate_sample_dataset(vocab)
man = S.validate_dataset(records, vocabulary=vocab)
splits = S.split_dataset(records, val_fraction=0.2, test_fraction=0.25, seed=42)
tot = lambda r: sum(r["counts"].values())
res = {"n": len(records), "classes": man["classes"], "split": {k: len(v) for k, v in splits.items()}}
by = {}
for r in records:
    by.setdefault(r["label"], []).append(tot(r))
res["P3_library_size_by_class"] = {c: {"n": len(v), "min": min(v), "max": max(v), "mean": round(statistics.mean(v), 2), "distinct": len(set(v))} for c, v in by.items()}
lib = M.library_size_baseline(splits["train"], splits["test"], man["classes"])
maj = M.majority_baseline(splits["train"], splits["test"], man["classes"])
res["P3_library_size_baseline"] = {k: lib[k] for k in ("rule", "train_accuracy", "accuracy", "macro_f1", "auroc")}
res["P3_majority_baseline"] = {k: maj[k] for k in ("predicted_label", "accuracy", "macro_f1")}
res["P3_test_totals"] = sorted([(tot(r), r["label"]) for r in splits["test"]])
# permutation reference for the test AUROC of total counts: how unusual is the observed value under random labels?
import random
y = [1 if r["label"] == man["classes"][-1] else 0 for r in splits["test"]]
x = [tot(r) for r in splits["test"]]
obs = M.auroc(y, x)
rng = random.Random(0); ge = 0
for _ in range(5000):
    yy = y[:]; rng.shuffle(yy)
    a = M.auroc(yy, x)
    if a is not None and max(a, 1 - a) >= max(obs, 1 - obs): ge += 1
res["P3_auroc_total_counts_test"] = {"observed": obs, "two_sided_permutation_p": round(ge / 5000, 4)}

# P4 BYOD
def put(name, text):
    p = out / name; p.write_text(text); return p
genes = vocab.gene_symbols[:40]
row = lambda i, lab: ",".join([f"c{i}"] + [str((i * 7 + k) % 13) for k in range(len(genes))] + [lab])
csv_ok = "id," + ",".join(genes) + ",label\n" + "\n".join(row(i, "a" if i % 2 else "b") for i in range(10)) + "\n"
cases = {
    "csv_ok_10": put("ok.csv", csv_ok),
    "csv_ensembl_ids": put("ens.csv", "id," + ",".join(f"ENSG{k:011d}" for k in range(40)) + ",label\n" + "\n".join(",".join([f"c{i}"] + ["3"] * 40 + ["a" if i % 2 else "b"]) for i in range(10)) + "\n"),
    "csv_one_class": put("one.csv", csv_ok.replace(",a\n", ",b\n")),
    "csv_negative": put("neg.csv", csv_ok.replace("c1,", "c1,-5,", 1).replace(",label", ",label", 1)),
    "jsonl_ok": put("ok.jsonl", "\n".join(json.dumps({"id": f"j{i}", "counts": {g: (i + k) % 9 for k, g in enumerate(genes)}, "label": "x" if i < 5 else "y"}) for i in range(10))),
    "json_dup_ids": put("dup.json", json.dumps([{"id": "same", "counts": {g: 1 for g in genes}, "label": "x" if i < 5 else "y"} for i in range(10)])),
    "txt_extension": put("data.txt", "hello"),
}
p4 = {}
for name, path in cases.items():
    try:
        recs = S.load_byod_dataset(path)
        m = S.validate_dataset(recs, vocabulary=vocab)
        p4[name] = {"accepted": True, "n": m["n_records"], "classes": m["classes"], "encodable_genes": m["encodable_genes"]}
    except Exception as exc:
        p4[name] = {"accepted": False, "error": f"{type(exc).__name__}: {exc}"[:220]}
res["P4"] = p4
nb = json.loads((repo / "tutorials/scgpt_single_cell_colab.ipynb").read_text())
src = next("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code" and "USE_BYOD = False" in "".join(c["source"]))
try:
    exec(compile("USE_BYOD = True\nif USE_BYOD:\n    from google.colab import files\n", "byod", "exec"), {})
    res["P4_upload_outside_colab"] = "no error"
except Exception as exc:
    res["P4_upload_outside_colab"] = f"{type(exc).__name__}: {exc}"
res["P4_cell_has_path_field"] = "BYOD_PATH" in src
(out / "results.json").write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
